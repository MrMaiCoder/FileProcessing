#!/bin/bash

unzip -oj $1 -d $2 &> tmp
rm tmp

